package com.xamarin.textcounter;

/**
 * Created by Mark McLemore on 2/2/16.
 */
public class TextCounter {

    // Array of vowels to compare against:
    static char[] vowels = new char []
    {
        'a', 'e', 'i', 'o', 'u', 'A', 'E', 'I', 'O', 'U'
    };

    // Count the number of vowels in the passed text string:
    public static int numVowels(String text) {

        // Vowel counter:
        int vowelCount = 0;

        // Comparison loop:
        for (int i = 0; i < text.length(); i++) {
            for (int j = 0; j < vowels.length; j++) {
                if (text.charAt(i) == vowels[j])
                    vowelCount++;
            }
        }
        return vowelCount;
    }
    // Count the number of consonants in the passed text string:
    public static int numConsonants (String text) {
        // Consonant counter:
        int consonantCount = 0;

        // Comparison loop:
        for (int i = 0; i < text.length(); i++) {
            if (Character.isLetter(text.charAt(i))) {

                boolean isVowel = false;

                // Is this letter a vowel?
                for (int j = 0; j < vowels.length; j++) {
                    if (text.charAt(i) == vowels[j])
                        isVowel = true;
                }
                // If it's a letter but not a vowel, it's a consonant:
                if (!isVowel) {
                    consonantCount++;
                }
            }
        }
        return consonantCount;
    }
}
